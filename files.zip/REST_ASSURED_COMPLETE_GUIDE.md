# REST Assured Complete Guide — SBIePay API Automation Framework

> **From Zero to Enterprise-Grade API Automation**
> A comprehensive reference for the SBIePay REST Assured Framework covering architecture,
> concepts, code, best practices, interview questions, and CI/CD.

---

## Table of Contents

1. [Step 1 — API Analysis & Dependency Flow](#step-1--api-analysis--dependency-flow)
2. [Step 2 — Production-Grade Folder Structure](#step-2--production-grade-folder-structure)
3. [Step 3 — Framework Architecture Overview](#step-3--framework-architecture-overview)
4. [Step 4 — REST Assured Concepts (Complete Teaching)](#step-4--rest-assured-concepts)
5. [Step 5 — Maven Project & Dependencies](#step-5--maven-project--dependencies)
6. [Step 6 — Framework Classes Reference](#step-6--framework-classes-reference)
7. [Step 7 — Payload Management (8 Approaches Compared)](#step-7--payload-management)
8. [Step 8 — JSON Template Deep Dive](#step-8--json-template-deep-dive)
9. [Step 9 — Response Validation Strategy](#step-9--response-validation-strategy)
10. [Step 10 — Assertions Deep Dive](#step-10--assertions-deep-dive)
11. [Step 11 — Service Layer & Tests](#step-11--service-layer--tests)
12. [Step 12 — TestNG Suite Configuration](#step-12--testng-suite-configuration)
13. [Step 13 — Enterprise Logging](#step-13--enterprise-logging)
14. [Step 14 — Reporting](#step-14--reporting)
15. [Step 15 — Flaky API Handling & Retry](#step-15--flaky-api-handling--retry)
16. [Step 16 — E2E Business Flow](#step-16--e2e-business-flow)
17. [Step 17 — CI/CD, Docker, Environment Management](#step-17--cicd-docker-environment-management)
18. [Step 18 — Complete File Reference](#step-18--complete-file-reference)
19. [Interview Questions Bank](#interview-questions-bank)
20. [Common Mistakes & Anti-Patterns](#common-mistakes--anti-patterns)

---

## Step 1 — API Analysis & Dependency Flow

### 1.1 APIs Identified

| # | API Name | Method | Endpoint | Auth Type | Encrypted? |
|---|----------|--------|----------|-----------|------------|
| 1 | Access Token | POST | `/transaction/v1/token/access` | API Key + Secret (headers) | No |
| 2 | Customer Create | POST | `/transaction/v1/customer/create` | ACCESS Token (Bearer) | Yes |
| 3 | Customer Retrieve | GET | `/transaction/v1/customer/{customerId}` | ACCESS Token (Bearer) | No |
| 4 | Customer Status Update | POST | `/transaction/v1/customer/{customerId}/{status}` | ACCESS Token (Bearer) | No |
| 5 | Order Create | POST | `/transaction/v1/order/create` | ACCESS Token (Bearer) | Yes |
| 6 | Order Status Update | POST | `/transaction/v1/order/update-status` | ACCESS Token (Bearer) | No |
| 7 | Transaction Token | POST | `/transaction/v1/token/txn/{orderHash}` | x-referrer header | No |
| 8 | Booking | POST | `/transaction/v1/booking/{orderHash}` | TXN Token (Bearer) | No |
| 9 | Payment Initiation DC | POST | `/transaction/v1/payment/initiation/DC` | TXN Token (Bearer) | Yes |

### 1.2 Business Flow (E2E)

```
┌─────────────────┐
│  Access Token    │  Merchant authenticates → receives JWT
│  (Merchant Auth) │  Used for: Customer + Order APIs
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Customer Create  │  Creates customer profile (encrypted)
│                  │  Returns: customerId
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Customer Retrieve│  Verifies customer was created
│ (Optional)       │  Uses: customerId from previous step
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Order Create    │  Creates payment order (encrypted)
│                  │  Returns: orderRefNumber, sbiOrderRefNumber, orderHash
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Order Status     │  Moves order → ATTEMPTED
│ Update           │  Uses: orderRefNumber, sbiOrderRefNumber
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Transaction      │  Generates payment-phase token
│ Token            │  Uses: orderHash   Returns: txnToken + hval
└────────┬────────┘
         │  ← TOKEN SWITCH: From ACCESS to TRANSACTION
         ▼
┌─────────────────┐
│    Booking       │  Locks order for payment
│                  │  Returns: orderInfo, merchantInfo, paymodes
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Payment          │  Submits card details (encrypted)
│ Initiation DC    │  Final step — processes payment
└─────────────────┘
```

### 1.3 Dual Token System

This is a **critical architectural pattern**. SBIePay uses two different JWT tokens:

**ACCESS Token** — For merchant-side operations (customer, order management). Generated using Merchant-API-Key-Id and Merchant-API-Key-Secret headers.

**TRANSACTION Token** — For payment-side operations (booking, payment). Generated per-order using the orderHash. Also returns `hval` which is used as the encryption key for payment requests.

**Why two tokens?** Security isolation. Even if the merchant token is compromised, it cannot initiate payments. The transaction token is short-lived and order-specific.

### 1.4 Encryption Pattern

Encrypted APIs wrap the actual payload:

```json
{
  "encryptRequest": {
    "merchantCustomerId": "CUST001",
    "customerName": "Test User",
    ...
  },
  "key": "hval_from_token_response"
}
```

The `encryptRequest` field contains the actual business data. The `key` field is the `hval` value from the Transaction Token response (or the configured encryption key for access-token-based APIs).

Algorithm: AES/CBC/PKCS5Padding with a derived key and IV.

### 1.5 Standard Response Pattern

**Success:**
```json
{
  "status": 1,
  "data": [ { ...actual response object... } ]
}
```

**Error:**
```json
{
  "status": 0,
  "errors": [
    { "errorCode": "2001", "errorMessage": "Field is required" }
  ]
}
```

### 1.6 Error Codes Reference

| Code | Meaning | Example Scenario |
|------|---------|-----------------|
| 2001 | Required field missing | `customerName` not sent |
| 2002 | Invalid format | Invalid email format |
| 2003 | Not found | Customer ID doesn't exist |
| 2004 | Already exists | Duplicate merchantCustomerId |
| 2007 | Max length exceeded | Name > 100 chars |
| 2010 | Leading/trailing spaces | `" John "` instead of `"John"` |
| 403 | Forbidden | Using ACCESS token for booking |

### 1.7 Dependency Flow Diagram (Mermaid)

```mermaid
graph TD
    A[Merchant Credentials] -->|POST /token/access| B[ACCESS Token]
    B -->|Bearer Auth| C[Customer Create]
    B -->|Bearer Auth| D[Customer Retrieve]
    B -->|Bearer Auth| E[Customer Status Update]
    B -->|Bearer Auth| F[Order Create]
    B -->|Bearer Auth| G[Order Status Update]
    
    C -->|customerId| D
    C -->|customerId| E
    C -->|customerId| F
    
    F -->|orderHash| H[Transaction Token]
    F -->|orderRefNumber, sbiOrderRefNumber| G
    
    H -->|txnToken| I[Booking]
    H -->|hval| J[Encryption Key for Payment]
    
    I -->|paymodes| K[Payment Initiation DC]
    J -->|key field| K
    
    style B fill:#e1f5fe
    style H fill:#fff3e0
    style K fill:#e8f5e9
```

---

## Step 2 — Production-Grade Folder Structure

```
sbiepay-api-framework/
├── pom.xml                              ← Maven build config
├── Jenkinsfile                          ← CI/CD pipeline
├── Dockerfile                           ← Containerised execution
├── .github/workflows/api-tests.yml      ← GitHub Actions
├── .gitignore
├── REST_ASSURED_COMPLETE_GUIDE.md       ← This document
│
├── src/main/java/com/sbiepay/automation/
│   │
│   ├── config/                          ← CONFIGURATION LAYER
│   │   ├── FrameworkConfig.java         │  Type-safe config via Owner library
│   │   └── ConfigFactory.java           │  Singleton config provider
│   │
│   ├── constants/                       ← CONSTANTS
│   │   └── ApiConstants.java            │  Endpoints, headers, error codes, timeouts
│   │
│   ├── core/client/                     ← HTTP CLIENT LAYER
│   │   └── ApiClient.java              │  Central REST Assured client (GET/POST/PUT/DELETE)
│   │
│   ├── auth/                            ← AUTHENTICATION
│   │   └── TokenManager.java           │  Thread-safe dual-token management
│   │
│   ├── encryption/                      ← ENCRYPTION
│   │   └── EncryptionUtil.java         │  AES/CBC encrypt + decrypt
│   │
│   ├── models/                          ← DATA MODELS (POJOs)
│   │   ├── requests/                    │  Request DTOs with Lombok @Builder
│   │   │   ├── CustomerCreateRequest
│   │   │   ├── OrderCreateRequest
│   │   │   ├── OrderStatusUpdateRequest
│   │   │   ├── TransactionTokenRequest
│   │   │   ├── PaymentInitiationDCRequest
│   │   │   └── EncryptedRequestWrapper
│   │   └── responses/                   │  Response DTOs
│   │       ├── ApiResponse (generic)
│   │       ├── CustomerResponse
│   │       ├── OrderResponse
│   │       └── TransactionTokenResponse
│   │
│   ├── services/                        ← SERVICE LAYER (Business Logic)
│   │   ├── CustomerService.java        │  Customer CRUD operations
│   │   ├── OrderService.java           │  Order create + status update
│   │   └── TransactionService.java     │  Booking + Payment
│   │
│   ├── validators/                      ← RESPONSE VALIDATION
│   │   └── ResponseValidator.java      │  Fluent assertion chain
│   │
│   ├── filters/                         ← REQUEST/RESPONSE FILTERS
│   │   ├── RequestLoggingFilter.java   │  Logs + masks sensitive data
│   │   └── ResponseLoggingFilter.java  │  Response logging
│   │
│   ├── utils/                           ← UTILITIES
│   │   ├── DataGenerator.java          │  Random test data (Indian locale)
│   │   └── JsonUtil.java              │  Template loading + placeholder injection
│   │
│   ├── retry/                           ← RETRY MECHANISM
│   │   ├── RetryAnalyzer.java          │  Exponential backoff
│   │   └── RetryTransformer.java       │  Auto-applies to all tests
│   │
│   ├── reports/                         ← REPORTING
│   │   └── ExtentManager.java          │  Thread-safe Extent Reports
│   │
│   ├── listeners/                       ← TESTNG LISTENERS
│   │   └── TestListener.java           │  Hooks into Extent Reports
│   │
│   └── exceptions/                      ← CUSTOM EXCEPTIONS
│       ├── FrameworkException.java
│       ├── ApiException.java
│       └── EncryptionException.java
│
├── src/main/resources/
│   ├── config/config.properties         ← Default settings
│   ├── environments/                    ← Per-env overrides
│   │   ├── sit.properties
│   │   ├── uat.properties
│   │   └── prod.properties
│   ├── log4j2.xml                       ← Logging configuration
│   └── testdata/json/
│       ├── requests/                    ← JSON request templates
│       │   ├── customer_create.json
│       │   ├── order_create.json
│       │   ├── order_status_update.json
│       │   ├── transaction_token.json
│       │   └── payment_initiation_dc.json
│       └── schemas/                     ← JSON Schemas for validation
│           ├── success_response.json
│           ├── error_response.json
│           ├── customer_create_response.json
│           └── order_create_response.json
│
├── src/test/java/com/sbiepay/automation/tests/
│   ├── BaseTest.java                    ← Parent for all tests
│   ├── smoke/
│   │   └── AccessTokenTest.java         ← 5 smoke tests
│   ├── regression/
│   │   ├── CustomerTest.java            ← 10+ tests (positive + negative)
│   │   └── OrderTest.java              ← 8+ tests (positive + negative)
│   └── e2e/
│       └── PaymentFlowE2ETest.java     ← 8 tests (full flow + security)
│
└── src/test/resources/suites/
    ├── testng-smoke.xml
    ├── testng-regression.xml
    └── testng-e2e.xml
```

### Why Each Package Exists

| Package | Purpose | Why It Matters |
|---------|---------|---------------|
| `config` | Type-safe configuration via Owner library | No more raw `Properties.getProperty()` with typos. Compile-time safety. |
| `constants` | All magic strings in one place | Change an endpoint once → applies everywhere. No scattered hardcoding. |
| `core/client` | Central HTTP client wrapping REST Assured | Every API call goes through one place. Easy to add logging, retry, auth. |
| `auth` | Token management with caching | Avoids generating a new token for every test. Thread-safe for parallel runs. |
| `encryption` | AES encryption/decryption | SBIePay requires encrypted payloads. Centralised = consistent. |
| `models/requests` | Request POJOs with `@Builder` | Type-safe payload construction. Compile-time field validation. |
| `models/responses` | Response POJOs | Deserialise responses into objects for easy field access. |
| `services` | Business-level API operations | Tests don't know HTTP details. Services encapsulate: build payload → encrypt → call API → return response. |
| `validators` | Fluent response validation chain | Reusable validation. No duplicate assertions across tests. |
| `filters` | Request/response logging filters | Automatically logs every call. Masks CVV, card numbers, tokens. |
| `utils` | Shared utilities (data gen, JSON handling) | DRY — used by services and tests alike. |
| `retry` | Retry analyzer + transformer | Flaky API handling without touching individual tests. |
| `reports` | Extent Reports integration | Beautiful HTML reports for stakeholders. |
| `listeners` | TestNG lifecycle hooks | Connects test events to reporting. |
| `exceptions` | Custom exception hierarchy | Meaningful error messages instead of generic NPE/RuntimeException. |

---

## Step 3 — Framework Architecture Overview

### 3.1 Layered Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                        TEST LAYER                                │
│   AccessTokenTest │ CustomerTest │ OrderTest │ PaymentFlowE2E    │
│                                                                  │
│   Tests contain ONLY business logic + assertions.                │
│   No HTTP details. No payload construction.                      │
└───────────────────────────┬──────────────────────────────────────┘
                            │ calls
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│                       SERVICE LAYER                              │
│       CustomerService │ OrderService │ TransactionService        │
│                                                                  │
│   Encapsulates: build payload → encrypt → make HTTP call         │
│   Returns raw Response for tests to validate.                    │
└───────────────────────────┬──────────────────────────────────────┘
                            │ uses
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│                        CORE LAYER                                │
│   ApiClient │ TokenManager │ EncryptionUtil │ ResponseValidator  │
│                                                                  │
│   Framework infrastructure. Knows REST Assured.                  │
│   Handles auth, encryption, HTTP, validation.                    │
└───────────────────────────┬──────────────────────────────────────┘
                            │ reads
                            ▼
┌──────────────────────────────────────────────────────────────────┐
│                     SUPPORT LAYER                                │
│   ConfigFactory │ DataGenerator │ JsonUtil │ ExtentManager       │
│                                                                  │
│   Cross-cutting: config, data, utilities, reporting.             │
└──────────────────────────────────────────────────────────────────┘
```

### 3.2 Design Principles Applied

**Separation of Concerns** — Tests know business rules, services know API details, core knows HTTP mechanics. Change one layer without breaking others.

**Single Responsibility** — `TokenManager` only manages tokens. `EncryptionUtil` only encrypts/decrypts. No god classes.

**DRY (Don't Repeat Yourself)** — Common validation in `ResponseValidator`. Common data in `DataGenerator`. Common HTTP setup in `ApiClient`.

**Builder Pattern** — POJOs use Lombok `@Builder` for readable payload construction.

**Fluent Interface** — `ResponseValidator` chains: `validate(response).validateSuccess().validateFieldNotNull("data[0].customerId").assertAll()`

**Factory Pattern** — `ConfigFactory` provides a singleton config instance. `RequestSpecification` factory in `ApiClient`.

---

## Step 4 — REST Assured Concepts

### 4.1 What Is REST Assured?

REST Assured is a Java library for testing RESTful APIs. It provides a domain-specific language (DSL) that makes HTTP requests and response validation readable and concise.

**Think of it as**: Selenium is for browser automation; REST Assured is for API automation.

**Why REST Assured over alternatives (HttpClient, OkHttp, Unirest)?**

| Feature | REST Assured | Apache HttpClient | OkHttp |
|---------|-------------|-------------------|--------|
| DSL for testing | Yes (given/when/then) | No | No |
| Built-in JSON/XML parsing | Yes | No | No |
| JSON Schema validation | Yes | No | No |
| BDD-style syntax | Yes | No | No |
| Request/Response logging | Built-in | Manual | Manual |
| Learning curve | Low | High | Medium |
| Test-focused | Yes | General HTTP client | General HTTP client |

### 4.2 The given()-when()-then() Pattern

This is the BDD (Behaviour-Driven Development) pattern that REST Assured follows:

```java
given()                              // ARRANGE — set up the request
    .baseUri("https://api.example.com")
    .header("Authorization", "Bearer xxx")
    .contentType(ContentType.JSON)
    .body(payload)
.when()                              // ACT — make the HTTP call
    .post("/transaction/v1/customer/create")
.then()                              // ASSERT — validate the response
    .statusCode(200)
    .body("status", equalTo(1))
    .body("data[0].customerId", notNullValue());
```

**What:** The three phases of a test — setup, execution, verification.
**Why:** Readable, self-documenting tests that read like English.
**When:** Every API test you write.
**Industry usage:** Universal across companies using REST Assured.

### 4.3 RequestSpecification

**What:** A pre-configured request template. Contains base URI, headers, content type, auth — anything common across multiple requests.

**Why:** Instead of repeating `given().baseUri().header().contentType()` in every test, you define it once.

**How we use it:**
```java
// In ApiClient.java — built once, reused everywhere
RequestSpecification spec = new RequestSpecBuilder()
    .setBaseUri(config.baseUrl())
    .setContentType(ContentType.JSON)
    .addFilter(new RequestLoggingFilter())
    .addFilter(new ResponseLoggingFilter())
    .build();
```

**Advantages:** DRY, consistent configuration, easy to change globally.
**Disadvantages:** Over-abstraction can hide what a test actually does.
**Best Practice:** Create a base spec + override per-request when needed.

### 4.4 ResponseSpecification

**What:** A pre-configured set of response expectations. Common checks applied to every response.

**Why:** If every API response should have `Content-Type: application/json` and respond within 30 seconds, define it once.

```java
ResponseSpecification responseSpec = new ResponseSpecBuilder()
    .expectContentType(ContentType.JSON)
    .expectResponseTime(lessThan(30000L))
    .build();
```

**Best Practice:** Use for universal checks. API-specific checks go in test methods.

### 4.5 Serialization & Deserialization

**What:** Converting Java objects → JSON (serialization) and JSON → Java objects (deserialization).

**Why:** Type-safe payload construction and response parsing. No raw string manipulation.

**Serialization (Java → JSON):**
```java
CustomerCreateRequest request = CustomerCreateRequest.builder()
    .merchantCustomerId("CUST001")
    .customerName("John Doe")
    .customerMobile("9876543210")
    .customerEmail("john@example.com")
    .build();

// REST Assured + Jackson automatically converts to JSON:
given().body(request).post("/customer/create");
```

**Deserialization (JSON → Java):**
```java
CustomerResponse customer = response.as(CustomerResponse.class);
String customerId = customer.getCustomerId();   // type-safe access
```

**Library:** Jackson (configured in pom.xml). REST Assured auto-detects it.

**Advantages:** Compile-time type safety. IDE autocomplete. Refactor-friendly.
**Disadvantages:** Requires POJO classes for each request/response shape.
**Best Practice:** Always use POJOs for production frameworks. HashMap only for quick prototypes.

### 4.6 JsonPath

**What:** A DSL for navigating JSON responses. Like XPath but for JSON.

**Why:** Extract specific values from complex nested JSON without deserializing the entire response.

```java
// Given response: {"status":1,"data":[{"customerId":"C001","status":"ACTIVE"}]}

response.jsonPath().getString("data[0].customerId");    // "C001"
response.jsonPath().getInt("status");                    // 1
response.jsonPath().getList("data");                     // [...]
response.jsonPath().getString("data[0].status");         // "ACTIVE"
```

**Common patterns:**
```java
// Array access
"data[0].field"          // first element
"data[-1].field"         // last element
"data.findAll{it.status=='ACTIVE'}"  // Groovy filter

// Nested access
"data[0].orderInfo.amount"
```

**When to use:** Quick value extraction. If you need many fields, deserialize to POJO instead.

### 4.7 Filters

**What:** Interceptors that execute before/after every HTTP call. Like Servlet filters for REST Assured.

**Why:** Cross-cutting concerns: logging, authentication, metrics, masking.

```java
// Adding filters to RequestSpecification
given()
    .filter(new RequestLoggingFilter())    // logs every request
    .filter(new ResponseLoggingFilter())   // logs every response
    .filter(new AllureFilter())            // Allure reporting hook
    .post("/endpoint");
```

**Our framework uses filters for:**
- Request logging with sensitive data masking (card numbers, CVV, tokens)
- Response logging with timing
- Correlation ID injection

**Interview Question:** "How do you log API requests without exposing sensitive data?" → "Custom Filter that regex-masks card numbers and tokens before logging."

### 4.8 Authentication Methods

REST Assured supports multiple auth types:

```java
// Basic Auth
given().auth().basic("user", "pass")

// Bearer Token
given().header("Authorization", "Bearer " + token)

// OAuth 2.0
given().auth().oauth2(accessToken)

// API Key in header
given().header("X-API-Key", apiKey)

// Preemptive (sends auth on first request, not after 401)
given().auth().preemptive().basic("user", "pass")
```

**SBIePay uses:** Bearer Token (for both ACCESS and TRANSACTION tokens) + API Key headers (for token generation).

### 4.9 Content Types

```java
given().contentType(ContentType.JSON)     // application/json
given().contentType(ContentType.XML)      // application/xml
given().contentType(ContentType.URLENC)   // application/x-www-form-urlencoded
given().contentType(ContentType.MULTIPART)// multipart/form-data
```

**SBIePay:** All APIs use `application/json`.

### 4.10 Response Validation Methods

```java
// Status code
.then().statusCode(200)

// Body using Hamcrest matchers
.then().body("status", equalTo(1))
.then().body("data", hasSize(1))
.then().body("data[0].customerId", notNullValue())
.then().body("data[0].email", matchesPattern("^[\\w]+@[\\w]+\\.[a-z]+$"))

// Headers
.then().header("Content-Type", containsString("json"))

// Response time
.then().time(lessThan(5000L))

// Extracting response for further checks
Response response = given()...when().post().then().extract().response();
```

### 4.11 Hamcrest Matchers (Most Used)

```java
equalTo(value)             // exact match
notNullValue()             // not null
nullValue()                // is null
hasSize(n)                 // collection size
greaterThan(n)             // numeric comparison
lessThan(n)
containsString("text")     // substring
matchesPattern("regex")    // regex match
hasItems("a", "b")         // collection contains
everyItem(greaterThan(0))  // all items match
```

---

## Step 5 — Maven Project & Dependencies

### 5.1 pom.xml Structure

The `pom.xml` is already generated in the framework. Here is what each dependency does:

| Dependency | Version | Purpose |
|-----------|---------|---------|
| `rest-assured` | 5.4.0 | Core API testing library |
| `json-schema-validator` | 5.4.0 | Validates response against JSON Schema |
| `testng` | 7.9.0 | Test framework (annotations, suites, parallel, groups) |
| `jackson-databind` | 2.17.0 | JSON serialization/deserialization |
| `jackson-datatype-jsr310` | 2.17.0 | Java 8 date/time support for Jackson |
| `lombok` | 1.18.32 | Reduces boilerplate (@Data, @Builder, @Slf4j) |
| `log4j2` (api + core + slf4j) | 2.23.1 | Enterprise logging framework |
| `extentreports` | 5.1.1 | Beautiful HTML test reports |
| `assertj-core` | 3.25.3 | Fluent assertion library (better than TestNG assert) |
| `poi + poi-ooxml` | 5.2.5 | Excel read/write for data-driven testing |
| `owner` | 1.0.12 | Type-safe property file management |
| `javafaker` | 1.0.2 | Random realistic test data |
| `bcprov-jdk18on` | 1.78 | BouncyCastle cryptography (AES encryption) |
| `json-path` | 2.9.0 | Jayway JsonPath for complex queries |
| `commons-io` | 2.16.1 | File utilities |
| `commons-lang3` | 3.14.0 | String utilities |

### 5.2 Maven Profiles

```xml
<!-- Environment profiles -->
<profiles>
    <profile><id>sit</id>  → Sets -Denv=sit</profile>
    <profile><id>uat</id>  → Sets -Denv=uat</profile>
    <profile><id>prod</id> → Sets -Denv=prod</profile>
</profiles>

<!-- Suite profiles -->
<profiles>
    <profile><id>smoke</id>      → Runs testng-smoke.xml</profile>
    <profile><id>regression</id> → Runs testng-regression.xml</profile>
    <profile><id>e2e</id>        → Runs testng-e2e.xml</profile>
</profiles>
```

**Run commands:**
```bash
mvn test -Psit -Psmoke           # Smoke on SIT
mvn test -Puat -Pregression      # Regression on UAT
mvn test -Psit -Pe2e             # E2E on SIT
```

### 5.3 Plugins

| Plugin | Purpose |
|--------|---------|
| `maven-surefire-plugin` | Runs unit tests (test phase) |
| `maven-failsafe-plugin` | Runs integration tests (verify phase) |
| `jacoco-maven-plugin` | Code coverage reports |
| `maven-compiler-plugin` | Java 17 source/target |

---

## Step 6 — Framework Classes Reference

### 6.1 Class Diagram (Mermaid)

```mermaid
classDiagram
    class BaseTest {
        #ApiClient apiClient
        #CustomerService customerService
        #OrderService orderService
        #TransactionService transactionService
        +validate(Response) ResponseValidator
        +logToReport(String, Response)
        +getEncryptionKey() String
    }
    
    class ApiClient {
        -RequestSpecification baseSpec
        -ResponseSpecification responseSpec
        +post(String, Object, Map) Response
        +get(String, Map) Response
        +postWithToken(String, Object, String) Response
    }
    
    class TokenManager {
        -String cachedAccessToken$
        -Map cachedTxnTokens$
        +getAccessToken()$ String
        +getTransactionToken(String)$ TransactionTokenResponse
    }
    
    class CustomerService {
        -ApiClient apiClient
        +createRandomCustomer(String) Response
        +createCustomer(CustomerCreateRequest, String) Response
        +retrieveCustomer(String) Response
        +updateCustomerStatus(String, String) Response
    }
    
    class ResponseValidator {
        -Response response
        -SoftAssertions soft
        +validateSuccess() ResponseValidator
        +validateStatusCode(int) ResponseValidator
        +validateFieldEquals(String, Object) ResponseValidator
        +validateFieldNotNull(String) ResponseValidator
        +validateErrorCode(String) ResponseValidator
        +assertAll()
    }
    
    BaseTest --> ApiClient
    BaseTest --> CustomerService
    BaseTest --> ResponseValidator
    CustomerService --> ApiClient
    CustomerService --> TokenManager
    ApiClient --> EncryptionUtil
```

### 6.2 Key Classes Summary

**ConfigFactory** — Loads environment-specific properties using the Owner library. Singleton pattern. `ConfigFactory.getConfig().baseUrl()` returns the base URL for the current environment.

**ApiClient** — Wraps all REST Assured HTTP operations. Creates `RequestSpecification` with base URI, content type, logging filters. Provides `post()`, `get()`, `postWithToken()` methods. Adds correlation IDs for traceability.

**TokenManager** — Thread-safe token management. Caches ACCESS tokens (re-uses until expired). Caches TRANSACTION tokens per orderHash. Auto-refreshes when expired.

**EncryptionUtil** — AES/CBC/PKCS5Padding encryption. `encrypt(plainText, key)` returns encrypted string. `decrypt(cipherText, key)` returns decrypted string. Uses key derivation from the provided key.

**ResponseValidator** — Fluent validation chain using soft assertions (from AssertJ). Validates: HTTP status, business status (1/0), specific fields, error codes, patterns, array sizes, JSON schemas, response time, headers.

**DataGenerator** — Generates random but realistic Indian test data: names, phone numbers (10-digit starting with 6-9), emails, addresses, PINs, amounts, order reference numbers.

**JsonUtil** — Loads JSON templates from `src/main/resources/testdata/json/requests/`. Replaces `${placeholder}` tokens with runtime values. Modifies/removes fields for negative tests.

---

## Step 7 — Payload Management

### 8 Approaches Compared

#### Approach 1: Hardcoded JSON String

```java
String body = "{\"merchantCustomerId\":\"CUST001\",\"customerName\":\"John\"}";
given().body(body).post("/customer/create");
```

| Aspect | Rating |
|--------|--------|
| Readability | Poor — escape characters, error-prone |
| Maintainability | Poor — string changes need careful editing |
| Type Safety | None |
| Dynamic Values | Manual string concatenation |
| Best For | Quick one-off debugging |
| Used By | Nobody in production |

#### Approach 2: HashMap

```java
Map<String, Object> body = new HashMap<>();
body.put("merchantCustomerId", "CUST001");
body.put("customerName", "John");
given().body(body).post("/customer/create");
```

| Aspect | Rating |
|--------|--------|
| Readability | Medium — clear key-value pairs |
| Maintainability | Medium — no compile-time key validation |
| Type Safety | None — values are Object |
| Dynamic Values | Easy — just put() |
| Best For | Prototyping, small payloads |
| Used By | Startups, small teams |

#### Approach 3: JSONObject (org.json)

```java
JSONObject body = new JSONObject();
body.put("merchantCustomerId", "CUST001");
body.put("customerName", "John");
given().body(body.toString()).post("/customer/create");
```

| Aspect | Rating |
|--------|--------|
| Readability | Medium |
| Maintainability | Medium |
| Type Safety | None |
| Dynamic Values | Easy |
| Best For | Working with raw JSON manipulation |
| Used By | Teams with heavy JSON transformation needs |

#### Approach 4: POJO with Jackson (OUR PRIMARY APPROACH)

```java
CustomerCreateRequest request = CustomerCreateRequest.builder()
    .merchantCustomerId("CUST001")
    .customerName("John")
    .customerMobile("9876543210")
    .customerEmail("john@example.com")
    .build();

given().body(request).post("/customer/create");
```

| Aspect | Rating |
|--------|--------|
| Readability | Excellent — builder pattern reads like English |
| Maintainability | Excellent — rename field → IDE refactors everywhere |
| Type Safety | Full compile-time safety |
| Dynamic Values | Builder methods + DataGenerator |
| Best For | Enterprise frameworks, large teams |
| Used By | Google, Amazon, Visa, Razorpay, JPMC, ThoughtWorks |

#### Approach 5: Builder Pattern (Custom)

Same as Approach 4 with Lombok `@Builder`. Manual builders add more boilerplate without benefit when Lombok is available.

#### Approach 6: External JSON Files (OUR SECONDARY APPROACH)

```java
// Load template: src/main/resources/testdata/json/requests/customer_create.json
String template = JsonUtil.readJsonTemplate("requests/customer_create.json");

// Inject dynamic values
Map<String, String> values = Map.of(
    "merchantCustomerId", DataGenerator.merchantCustomerId(),
    "customerName", DataGenerator.fullName()
);
String body = JsonUtil.injectValues(template, values);

given().body(body).post("/customer/create");
```

| Aspect | Rating |
|--------|--------|
| Readability | Good — templates are clean JSON files |
| Maintainability | Good — non-developers can modify templates |
| Type Safety | None at compile time |
| Dynamic Values | Placeholder injection |
| Best For | API contract templates, data-driven testing |
| Used By | Large QA teams, consulting companies (EPAM, Publicis Sapient) |

#### Approach 7: Template Engine (Mustache/Handlebars)

Full template engine for complex logic inside JSON. Overkill for most API testing.

| Best For | Complex conditional payloads |
| Used By | Niche cases, API mocking |

#### Approach 8: Dynamic Payload Builder (Fluent)

```java
// Custom fluent builder that generates JSON directly
Payload.create()
    .set("merchantCustomerId", DataGenerator.merchantCustomerId())
    .set("customerName", DataGenerator.fullName())
    .setNested("address.city", "Mumbai")
    .removeField("gstNumber")
    .toJson();
```

| Best For | Negative testing (remove/modify fields dynamically) |
| Used By | Combined with POJO approach for negative tests |

### Recommendation

**Use Approach 4 (POJO + Builder) as the primary strategy** for all positive/happy-path tests. Compile-time safety, IDE support, and refactoring make it the clear enterprise winner.

**Use Approach 6 (External JSON) as secondary** for data-driven tests and when non-technical team members need to add test data.

**Use Approach 8 (Dynamic Builder via JsonUtil)** for negative tests where you need to remove/modify/corrupt specific fields.

This is exactly what our framework implements.

---

## Step 8 — JSON Template Deep Dive

### 8.1 How Templates Work

Templates are plain JSON files stored in `src/main/resources/testdata/json/requests/`. They contain `${placeholder}` tokens that get replaced at runtime.

**Template file (`customer_create.json`):**
```json
{
  "merchantCustomerId": "${merchantCustomerId}",
  "customerName": "${customerName}",
  "customerMobile": "${customerMobile}",
  "customerEmail": "${customerEmail}",
  "gstNumber": "${gstNumber}"
}
```

### 8.2 Runtime Value Injection

```java
// In JsonUtil.java:
public static String injectValues(String template, Map<String, String> values) {
    String result = template;
    for (Map.Entry<String, String> entry : values.entrySet()) {
        result = result.replace("${" + entry.getKey() + "}", entry.getValue());
    }
    return result;
}
```

### 8.3 Dynamic ID Replacement

When APIs return IDs that the next API needs:
```java
// Step 1: Create customer → get customerId
String customerId = response.jsonPath().getString("data[0].customerId");

// Step 2: Use that customerId in order template
Map<String, String> orderValues = Map.of(
    "customerId", customerId,  // dynamic from previous response
    "orderRefNumber", DataGenerator.orderRefNumber(),
    "orderAmount", "500"
);
```

### 8.4 Random Value Generation

```java
Map<String, String> values = Map.of(
    "merchantCustomerId", DataGenerator.merchantCustomerId(),  // "MCUST-abc12345"
    "customerName", DataGenerator.fullName(),                   // "Priya Sharma"
    "customerMobile", DataGenerator.indianMobile(),             // "9876543210"
    "customerEmail", DataGenerator.email()                      // "priya.sharma@test.com"
);
```

### 8.5 Modifying Fields for Negative Tests

```java
// Remove a required field
String modified = JsonUtil.removeField(template, "customerName");
// Result: {"merchantCustomerId":"...","customerMobile":"...","customerEmail":"..."}

// Set a field to null
String modified = JsonUtil.setFieldNull(template, "customerName");
// Result: {"merchantCustomerId":"...","customerName":null,...}

// Set a field to empty string
String modified = JsonUtil.setFieldValue(template, "customerName", "");

// Set boundary value
String modified = JsonUtil.setFieldValue(template, "customerName", "A".repeat(101));
```

### 8.6 Nested JSON Modification

```java
// For deeply nested structures like payment request:
ObjectMapper mapper = new ObjectMapper();
JsonNode root = mapper.readTree(template);
((ObjectNode) root.path("deviceDetail")).put("ip", "192.168.1.1");
String modified = mapper.writeValueAsString(root);
```

### 8.7 Encryption After Template Injection

```java
// 1. Load template + inject values → plain JSON string
String plainPayload = JsonUtil.injectValues(template, values);

// 2. Encrypt the entire payload
String encrypted = EncryptionUtil.encrypt(plainPayload, encryptionKey);

// 3. Wrap in the encrypted request format
EncryptedRequestWrapper wrapper = EncryptedRequestWrapper.builder()
    .encryptRequest(encrypted)
    .key(hvalKey)
    .build();

// 4. Send wrapped payload
given().body(wrapper).post("/customer/create");
```

---

## Step 9 — Response Validation Strategy

### 9.1 What Should Every API Response Validate?

| Validation | Why | Priority |
|-----------|-----|----------|
| HTTP Status Code | Basic contract — 200, 201, 400, 401, 403, 404, 500 | Critical |
| Business Status | Application-level success/failure (status: 1 or 0) | Critical |
| Response Time | SLA enforcement (< 3s for most APIs) | High |
| Content-Type Header | Ensures JSON response | High |
| Mandatory Fields | Required fields must be non-null | Critical |
| Data Types | String fields are strings, numbers are numbers | High |
| Error Codes | Correct error code for the failure scenario | Critical |
| Error Messages | Meaningful, not generic | Medium |
| JSON Schema | Structural contract validation | High |
| Business Rules | Amount > 0, status in valid set, dates in future | Critical |
| Null/Empty Checks | Distinguishes null vs empty vs missing | Medium |
| Array Size | Expected number of items | Medium |
| Nested JSON | Deep field validation | Medium |
| Regex Patterns | Email, phone, UUID formats | Medium |
| Date Formats | ISO 8601 or expected format | Medium |

### 9.2 Our ResponseValidator Implementation

```java
// Fluent chain — reads like a specification
validate(response)
    .validateStatusCode(200)             // HTTP level
    .validateSuccess()                    // business status=1
    .validateResponseTime(3000)           // under 3 seconds
    .validateContentType("application/json")
    .validateFieldNotNull("data[0].customerId")
    .validateFieldEquals("data[0].status", "ACTIVE")
    .validateFieldPattern("data[0].customerEmail", "^[\\w.]+@[\\w]+\\.[a-z]+$")
    .validateArraySize("data", 1)
    .validateJsonSchema("schemas/customer_create_response.json")
    .assertAll();                         // soft assert — reports ALL failures
```

### 9.3 JSON Schema Validation

JSON Schema is a contract definition for your API response structure. It validates:
- Required fields are present
- Data types are correct
- String patterns match
- Number ranges are valid
- Enum values are from the allowed set

```json
// Schema file: customer_create_response.json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["status", "data"],
  "properties": {
    "status": { "type": "integer", "enum": [1] },
    "data": {
      "type": "array",
      "items": {
        "required": ["customerId", "status"],
        "properties": {
          "customerId": { "type": "string", "minLength": 1 },
          "status": { "type": "string", "enum": ["ACTIVE", "INACTIVE"] }
        }
      }
    }
  }
}
```

```java
// In ResponseValidator:
given().when().post().then()
    .body(matchesJsonSchemaInClasspath("schemas/customer_create_response.json"));
```

---

## Step 10 — Assertions Deep Dive

### 10.1 Hard Assert (TestNG)

```java
Assert.assertEquals(response.getStatusCode(), 200);
Assert.assertNotNull(response.jsonPath().getString("data[0].customerId"));
```

**Behaviour:** Fails immediately on first assertion failure. Subsequent assertions don't execute.

**When to use:** When one failure makes remaining checks meaningless. Example: if status code is 500, checking body fields is pointless.

**Disadvantage:** In a test with 10 assertions, if assertion #2 fails, you don't know about assertions #3-10.

### 10.2 Soft Assert (TestNG)

```java
SoftAssert soft = new SoftAssert();
soft.assertEquals(response.getStatusCode(), 200, "Status code mismatch");
soft.assertNotNull(body.getCustomerId(), "Customer ID is null");
soft.assertEquals(body.getStatus(), "ACTIVE", "Status mismatch");
soft.assertAll();  // reports ALL failures at once
```

**Behaviour:** Collects all assertion failures, then reports them together at `assertAll()`.

**When to use:** When you want a complete picture of all failures in one run. Most API tests should use soft assertions.

### 10.3 AssertJ (OUR PRIMARY CHOICE)

```java
// Fluent, readable, rich error messages
assertThat(response.getStatusCode())
    .as("HTTP Status Code")
    .isEqualTo(200);

assertThat(customerId)
    .as("Customer ID")
    .isNotNull()
    .isNotEmpty()
    .startsWith("CUST");

assertThat(response.time())
    .as("Response Time SLA")
    .isLessThan(3000L);

// Collection assertions
assertThat(errors)
    .extracting("errorCode")
    .contains("2001");
```

**Advantages over TestNG Assert:**
- Fluent chain syntax
- Better error messages (shows expected + actual + context)
- Rich collection/string/date matchers
- `.as()` for custom error descriptions

### 10.4 Soft Assertions (AssertJ) — Used in ResponseValidator

```java
SoftAssertions soft = new SoftAssertions();
soft.assertThat(statusCode).as("HTTP Status").isEqualTo(200);
soft.assertThat(businessStatus).as("Business Status").isEqualTo(1);
soft.assertThat(customerId).as("Customer ID").isNotNull();
soft.assertAll();  // collects ALL failures
```

This is what our `ResponseValidator` uses internally. Every `validate*()` method adds an assertion to the `SoftAssertions` instance. `assertAll()` triggers them all.

### 10.5 When to Use What

| Scenario | Recommended Assertion |
|----------|----------------------|
| Single critical check (status code before proceeding) | Hard Assert |
| Multiple independent checks on one response | Soft Assert (AssertJ) |
| Chaining readable validations | ResponseValidator (fluent soft) |
| Schema structural validation | JSON Schema + Hard Assert |
| Collection/array checks | AssertJ `assertThat(list)` |

---

## Step 11 — Service Layer & Tests

### 11.1 Service Layer Pattern

Services encapsulate the complexity of calling an API:

```
Test Method → Service Method → [Build Payload + Encrypt + Add Auth + Call API] → Response
```

Tests never touch REST Assured directly. They call service methods and validate responses.

**CustomerService example flow:**
```java
public Response createRandomCustomer(String encryptionKey) {
    // 1. Generate random data
    CustomerCreateRequest request = CustomerCreateRequest.builder()
        .merchantCustomerId(DataGenerator.merchantCustomerId())
        .customerName(DataGenerator.fullName())
        .customerMobile(DataGenerator.indianMobile())
        .customerEmail(DataGenerator.email())
        .build();
    
    // 2. Serialize to JSON
    String jsonPayload = new ObjectMapper().writeValueAsString(request);
    
    // 3. Encrypt
    String encrypted = EncryptionUtil.encrypt(jsonPayload, encryptionKey);
    
    // 4. Wrap in encrypted request format
    EncryptedRequestWrapper wrapper = EncryptedRequestWrapper.builder()
        .encryptRequest(encrypted)
        .key(encryptionKey)
        .build();
    
    // 5. Make HTTP call with access token
    return apiClient.postWithAccessToken(
        ApiConstants.Endpoints.CUSTOMER_CREATE, wrapper);
}
```

### 11.2 Test Examples

**Positive test:**
```java
@Test(groups = {"regression", "smoke"})
public void testCreateCustomer_AllFields_Success() {
    Response response = customerService.createRandomCustomer(getEncryptionKey());
    
    validate(response)
        .validateSuccess()
        .validateFieldNotNull("data[0].customerId")
        .validateFieldEquals("data[0].status", "ACTIVE")
        .assertAll();
}
```

**Negative test (missing mandatory field):**
```java
@Test(groups = {"regression", "negative"})
public void testCreateCustomer_MissingName_Error2001() {
    Response response = customerService.createCustomerMissingField("customerName", getEncryptionKey());
    
    validate(response)
        .validateStatusCode(200)     // SBIePay returns 200 even for business errors
        .validateBusinessError()     // status=0
        .validateErrorCode("2001")   // required field
        .assertAll();
}
```

**Boundary test:**
```java
@Test(groups = {"regression", "boundary"})
public void testCreateCustomer_NameMaxLength_Error2007() {
    Response response = customerService.createCustomerWithField(
        "customerName", "A".repeat(101), getEncryptionKey());
    
    validate(response)
        .validateBusinessError()
        .validateErrorCode("2007")  // max length exceeded
        .assertAll();
}
```

---

## Step 12 — TestNG Suite Configuration

### 12.1 Suite Types & When to Run

| Suite | Contents | When | Duration |
|-------|---------|------|----------|
| Smoke | 1-2 happy paths per API | After every deployment | < 2 min |
| Regression | All positive + negative + boundary | Nightly / PR merge | 5-15 min |
| E2E | Complete business flow | Pre-release | 3-8 min |

### 12.2 TestNG Features Used

**Groups:** `@Test(groups = {"regression", "negative"})` — categorise tests without duplication.

**Dependencies:** `@Test(dependsOnMethods = "step01_GenerateAccessToken")` — sequential E2E steps.

**Priority:** `@Test(priority = 1)` — execution order within a class.

**Parallel:** `parallel="tests"` in suite XML — run test blocks concurrently. Requires thread-safe code (our TokenManager handles this).

**Data Provider** (for data-driven tests):
```java
@DataProvider(name = "invalidEmails")
public Object[][] invalidEmails() {
    return new Object[][] {
        {"plaintext"},
        {"@missing-local.com"},
        {"user@.invalid"},
        {"user@domain"},
        {""},
        {null}
    };
}

@Test(dataProvider = "invalidEmails", groups = {"negative"})
public void testCreateCustomer_InvalidEmail(String email) {
    // ... test with each invalid email
}
```

**Listeners:** Automatically applied via suite XML — no `@Listeners` annotation needed in every test class.

---

## Step 13 — Enterprise Logging

### 13.1 Logging Levels

| Level | When to Use | Example |
|-------|------------|---------|
| TRACE | Ultra-detailed debugging | Raw byte arrays, internal state |
| DEBUG | Development details | "Building request payload for customer create" |
| INFO | Business events | "Customer created: CUST001" |
| WARN | Unexpected but recoverable | "Token expired, refreshing..." |
| ERROR | Failures | "API call failed: 500 Internal Server Error" |
| FATAL | Application-breaking | "Unable to load configuration file" |

### 13.2 What We Log

Every API call automatically logs (via RequestLoggingFilter + ResponseLoggingFilter):

```
12:34:56.789 INFO  [main] ApiClient — ══════════ API REQUEST ══════════
12:34:56.789 INFO  [main] ApiClient — POST https://api-sit.sbiepay.sbi/transaction/v1/customer/create
12:34:56.789 INFO  [main] ApiClient — Correlation-ID: a1b2c3d4-e5f6-7890
12:34:56.790 INFO  [main] ApiClient — Headers: {Authorization: Bearer eyJh***MASKED***}
12:34:56.790 INFO  [main] ApiClient — Body: {"encryptRequest":"***ENCRYPTED***","key":"***MASKED***"}
12:34:57.123 INFO  [main] ApiClient — ══════════ API RESPONSE ══════════
12:34:57.123 INFO  [main] ApiClient — Status: 200 (334ms)
12:34:57.123 INFO  [main] ApiClient — Body: {"status":1,"data":[{"customerId":"C001",...}]}
```

### 13.3 Sensitive Data Masking

The `RequestLoggingFilter` masks:
- Card numbers: `4111111111111111` → `411111******1111`
- CVV: `"cardSecurityCode":"123"` → `"cardSecurityCode":"***"`
- Bearer tokens: `Bearer eyJhbG...` → `Bearer eyJh***MASKED***`
- API keys: Similar masking

### 13.4 Correlation IDs

Every request gets a unique UUID added as a `X-Correlation-ID` header. This allows tracing a specific test request through server logs. Essential for debugging failures in shared test environments.

---

## Step 14 — Reporting

### 14.1 Extent Reports Configuration

Our `ExtentManager` creates thread-safe Extent Reports that include:

- **Dashboard** — Pass/fail/skip pie chart, execution time
- **Test Details** — Each test method with status, duration, steps
- **Request/Response Logs** — Full HTTP details embedded in each test node
- **Categories** — Tests grouped by: smoke, regression, negative, e2e
- **Environment Info** — Base URL, environment, Java version, OS

### 14.2 Report Generation Flow

```
Test starts → TestListener.onTestStart()
                → Creates ExtentTest node
                → Logs test description

Test executes → Service method called
                → logToReport() adds request/response details
                → Assertions run

Test ends → TestListener.onTestSuccess/Failure/Skip()
              → Marks ExtentTest as PASS/FAIL/SKIP
              → Adds exception details on failure

Suite ends → TestListener.onFinish()
               → ExtentManager.flush()
               → HTML file written to target/reports/extent-report.html
```

### 14.3 Viewing Reports

After running tests:
```bash
mvn test -Psit -Psmoke
# Open: target/reports/extent-report.html
```

---

## Step 15 — Flaky API Handling & Retry

### 15.1 What Makes APIs Flaky?

- **503 Service Unavailable** — Server temporarily overloaded
- **504 Gateway Timeout** — Upstream service slow
- **429 Too Many Requests** — Rate limited
- **Connection timeouts** — Network issues
- **Intermittent failures** — Shared test environment instability

### 15.2 Our Retry Implementation

```java
// RetryAnalyzer.java — applied to EVERY test via RetryTransformer
public class RetryAnalyzer implements IRetryAnalyzer {
    private int retryCount = 0;
    private static final int MAX_RETRY = 2;
    
    @Override
    public boolean retry(ITestResult result) {
        if (retryCount < MAX_RETRY) {
            retryCount++;
            long waitTime = (long) Math.pow(2, retryCount) * 1000; // exponential backoff
            Thread.sleep(waitTime);  // 2s, 4s
            return true;  // retry the test
        }
        return false;  // give up
    }
}
```

### 15.3 Exponential Backoff

Instead of retrying immediately (which could overwhelm the server), we wait progressively longer:

```
Attempt 1: fails → wait 2 seconds
Attempt 2: fails → wait 4 seconds
Attempt 3: fails → mark as FAILED
```

### 15.4 Rate Limiting Handling

If you get 429 responses, respect the `Retry-After` header:
```java
if (response.getStatusCode() == 429) {
    int retryAfter = Integer.parseInt(response.getHeader("Retry-After"));
    Thread.sleep(retryAfter * 1000L);
    // retry the request
}
```

### 15.5 Timeout Configuration

```properties
# In config.properties
connection.timeout=10000   # 10s to establish connection
read.timeout=30000         # 30s to receive response
```

### 15.6 Circuit Breaker Concept

If an API fails N times consecutively, stop calling it temporarily. This prevents overwhelming a failing service.

**In testing context:** If the Access Token API is down, skip all tests that depend on it (using TestNG `dependsOnMethods`). Don't waste 15 minutes running tests that will all fail.

### 15.7 Idempotency

**What:** Calling the same API multiple times with the same data produces the same result.

**Why it matters for testing:** If a test fails mid-execution and retries, idempotent APIs won't create duplicate data. Non-idempotent APIs (like Customer Create) might create duplicates — use unique IDs to handle this.

**Our approach:** `DataGenerator.merchantCustomerId()` generates unique IDs per invocation, so retries create new records instead of duplicates.

---

## Step 16 — E2E Business Flow

### 16.1 Complete Flow

```
Step 1: Generate Access Token
    → Input:  Merchant-API-Key-Id + Secret headers
    → Output: ACCESS JWT token (cached by TokenManager)

Step 2: Create Customer
    → Auth:   Bearer {accessToken}
    → Input:  Encrypted customer data
    → Output: customerId = "CUST001"

Step 3: Create Order
    → Auth:   Bearer {accessToken}
    → Input:  Encrypted order data (with customerId from Step 2)
    → Output: orderRefNumber, sbiOrderRefNumber, orderHash

Step 4: Update Order Status → ATTEMPTED
    → Auth:   Bearer {accessToken}
    → Input:  orderRefNumber + sbiOrderRefNumber + "ATTEMPTED"

Step 5: Generate Transaction Token
    → Input:  orderHash (path param) + device details
    → Output: txnToken (JWT) + hval (encryption key)
    ⚠️ TOKEN SWITCH: Subsequent APIs use txnToken, NOT accessToken

Step 6: Book Transaction
    → Auth:   Bearer {txnToken}
    → Input:  orderHash (path param)
    → Output: orderInfo, merchantInfo, paymodes (available payment methods)

Step 7: Initiate Payment (Debit Card)
    → Auth:   Bearer {txnToken}
    → Input:  Encrypted card details (using hval as key)
    → Output: Payment processing result
```

### 16.2 Dynamic Data Passing

The E2E test class uses instance variables to pass data between steps:

```java
private String customerId;        // from Step 2 → used in Step 3
private String orderRefNumber;    // from Step 3 → used in Step 4
private String sbiOrderRefNumber; // from Step 3 → used in Step 4
private String orderHash;         // from Step 3 → used in Steps 5, 6
```

TestNG `dependsOnMethods` ensures steps run in order and skip remaining steps if a dependency fails.

### 16.3 Security Negative Test

The E2E suite includes a critical security test: trying to use the ACCESS token for the Booking API (which requires a TRANSACTION token). This must return 403 Forbidden.

---

## Step 17 — CI/CD, Docker, Environment Management

### 17.1 Environment Management

Three environments configured via property files:

```
src/main/resources/
├── config/config.properties          ← defaults
└── environments/
    ├── sit.properties                ← overrides for SIT
    ├── uat.properties                ← overrides for UAT
    └── prod.properties               ← overrides for PROD
```

**How it works:** The Owner library loads `config.properties` first, then layers the environment-specific file on top. Any key redefined in the env file wins.

**Switching environments:**
```bash
mvn test -Denv=sit       # uses sit.properties
mvn test -Denv=uat       # uses uat.properties
mvn test -Denv=prod      # uses prod.properties (secrets from env vars)
```

### 17.2 Jenkins Pipeline

The `Jenkinsfile` provides:
- Parameterized builds (choose ENV + SUITE)
- Secrets from Jenkins Credential Store (never in code)
- Automatic report publishing (Extent + TestNG)
- Slack notifications on failure
- 30-minute timeout
- Build history cleanup (keep 20)

### 17.3 GitHub Actions

The `.github/workflows/api-tests.yml` provides:
- Smoke tests on every push to main/develop
- Regression tests on pull requests
- Nightly full regression (cron schedule)
- Manual dispatch with environment + suite selection
- Artifact upload (reports, logs)
- Test summary in GitHub PR

### 17.4 Docker

```bash
# Build once
docker build -t sbiepay-api-tests .

# Run with different configs
docker run --rm \
    -e ENV=sit -e SUITE=smoke \
    -e MERCHANT_API_KEY_ID=xxx \
    -e MERCHANT_API_KEY_SECRET=xxx \
    -e ENCRYPTION_KEY=xxx \
    -v $(pwd)/reports:/app/target/reports \
    sbiepay-api-tests
```

**Benefits:** Consistent execution environment. No "works on my machine" issues. Easy to run in any CI/CD system.

---

## Step 18 — Complete File Reference

All files in the framework with their locations:

| File | Path | Purpose |
|------|------|---------|
| pom.xml | `/pom.xml` | Maven build configuration |
| config.properties | `/src/main/resources/config/config.properties` | Default settings |
| sit.properties | `/src/main/resources/environments/sit.properties` | SIT environment |
| uat.properties | `/src/main/resources/environments/uat.properties` | UAT environment |
| prod.properties | `/src/main/resources/environments/prod.properties` | Production environment |
| log4j2.xml | `/src/main/resources/log4j2.xml` | Logging configuration |
| FrameworkConfig.java | `/src/main/java/.../config/` | Type-safe config interface |
| ConfigFactory.java | `/src/main/java/.../config/` | Config singleton |
| ApiConstants.java | `/src/main/java/.../constants/` | All constants |
| ApiClient.java | `/src/main/java/.../core/client/` | HTTP client |
| TokenManager.java | `/src/main/java/.../auth/` | Token management |
| EncryptionUtil.java | `/src/main/java/.../encryption/` | AES encryption |
| CustomerCreateRequest.java | `/src/main/java/.../models/requests/` | Customer request POJO |
| OrderCreateRequest.java | `/src/main/java/.../models/requests/` | Order request POJO |
| OrderStatusUpdateRequest.java | `/src/main/java/.../models/requests/` | Status update POJO |
| TransactionTokenRequest.java | `/src/main/java/.../models/requests/` | TXN token request |
| PaymentInitiationDCRequest.java | `/src/main/java/.../models/requests/` | Payment request |
| EncryptedRequestWrapper.java | `/src/main/java/.../models/requests/` | Encryption wrapper |
| ApiResponse.java | `/src/main/java/.../models/responses/` | Generic response |
| CustomerResponse.java | `/src/main/java/.../models/responses/` | Customer response |
| OrderResponse.java | `/src/main/java/.../models/responses/` | Order response |
| TransactionTokenResponse.java | `/src/main/java/.../models/responses/` | TXN token response |
| CustomerService.java | `/src/main/java/.../services/` | Customer operations |
| OrderService.java | `/src/main/java/.../services/` | Order operations |
| TransactionService.java | `/src/main/java/.../services/` | Transaction operations |
| ResponseValidator.java | `/src/main/java/.../validators/` | Fluent validator |
| RequestLoggingFilter.java | `/src/main/java/.../filters/` | Request logging |
| ResponseLoggingFilter.java | `/src/main/java/.../filters/` | Response logging |
| DataGenerator.java | `/src/main/java/.../utils/` | Test data generation |
| JsonUtil.java | `/src/main/java/.../utils/` | JSON template handling |
| RetryAnalyzer.java | `/src/main/java/.../retry/` | Retry logic |
| RetryTransformer.java | `/src/main/java/.../retry/` | Auto-applies retry |
| ExtentManager.java | `/src/main/java/.../reports/` | Report management |
| TestListener.java | `/src/main/java/.../listeners/` | TestNG listener |
| FrameworkException.java | `/src/main/java/.../exceptions/` | Base exception |
| ApiException.java | `/src/main/java/.../exceptions/` | API exception |
| EncryptionException.java | `/src/main/java/.../exceptions/` | Encryption exception |
| BaseTest.java | `/src/test/java/.../tests/` | Test parent class |
| AccessTokenTest.java | `/src/test/java/.../tests/smoke/` | Token tests |
| CustomerTest.java | `/src/test/java/.../tests/regression/` | Customer tests |
| OrderTest.java | `/src/test/java/.../tests/regression/` | Order tests |
| PaymentFlowE2ETest.java | `/src/test/java/.../tests/e2e/` | E2E flow tests |
| testng-smoke.xml | `/src/test/resources/suites/` | Smoke suite |
| testng-regression.xml | `/src/test/resources/suites/` | Regression suite |
| testng-e2e.xml | `/src/test/resources/suites/` | E2E suite |
| customer_create.json | `/src/main/resources/testdata/json/requests/` | Template |
| order_create.json | `/src/main/resources/testdata/json/requests/` | Template |
| Jenkinsfile | `/Jenkinsfile` | Jenkins pipeline |
| api-tests.yml | `/.github/workflows/` | GitHub Actions |
| Dockerfile | `/Dockerfile` | Container config |

---

## Interview Questions Bank

### REST Assured Questions

**Q: What is REST Assured and why use it over HttpClient?**
REST Assured is a Java library specifically designed for testing REST APIs. Unlike Apache HttpClient (a general-purpose HTTP client), REST Assured provides a BDD-style DSL (given/when/then), built-in JSON/XML parsing, Hamcrest matcher integration, and response validation — all optimised for testing rather than building HTTP clients.

**Q: Explain given().when().then() pattern.**
`given()` sets up the request (headers, body, auth, params). `when()` executes the HTTP method (GET, POST, PUT, DELETE). `then()` validates the response (status code, body, headers). This BDD pattern makes tests self-documenting and readable.

**Q: What is RequestSpecification and why use it?**
A pre-configured request template containing base URI, default headers, content type, and filters. It eliminates repetition across tests and ensures consistent configuration. Created via `RequestSpecBuilder` and shared across an entire test suite.

**Q: How do you handle authentication in REST Assured?**
Multiple ways: `given().auth().basic()` for Basic Auth, `given().auth().oauth2()` for OAuth, `given().header("Authorization", "Bearer " + token)` for Bearer tokens. For token-based systems, use a TokenManager that caches tokens and auto-refreshes on expiry.

**Q: Explain serialisation and deserialisation.**
Serialisation converts Java objects to JSON (request body construction). Deserialisation converts JSON responses to Java objects (type-safe field access). REST Assured uses Jackson automatically. Example: `given().body(myPojo)` serialises; `response.as(MyResponse.class)` deserialises.

**Q: What are REST Assured Filters?**
Interceptors that execute on every request/response. Used for logging, authentication injection, metrics collection, and sensitive data masking. Implement the `Filter` interface and add via `given().filter(myFilter)` or on the `RequestSpecBuilder`.

**Q: How do you validate JSON Schema in REST Assured?**
Using `io.restassured.module.jsv.JsonSchemaValidator`: `response.then().body(matchesJsonSchemaInClasspath("schema.json"))`. The schema defines required fields, types, patterns, and allowed values. Essential for API contract testing.

**Q: Soft Assert vs Hard Assert — when to use each?**
Hard Assert stops on first failure — use when subsequent checks are meaningless without the first passing (e.g., 200 status before checking body). Soft Assert collects all failures — use when you want a complete picture (e.g., validating 10 response fields).

**Q: How do you handle dynamic values across API calls?**
Extract from response using `response.jsonPath().getString("path")`, store in variables or TestNG ITestContext, and inject into subsequent request. Use `dependsOnMethods` in TestNG to ensure order. Our framework uses instance variables in E2E tests and service-layer methods for chaining.

**Q: Explain your retry mechanism.**
Custom `IRetryAnalyzer` with exponential backoff. On failure, retries after 2s, then 4s. Max 2 retries. Applied globally via `IAnnotationTransformer` (no per-test annotation needed). Handles transient failures like 503, timeouts, connection issues.

### Framework Design Questions

**Q: How do you manage multiple environments?**
Property files per environment (sit.properties, uat.properties, prod.properties) loaded via the Owner library. Maven profiles set the `-Denv` flag. The framework reads the env flag, loads the corresponding file, and all config (base URL, credentials, timeouts) adapts automatically.

**Q: How do you handle encrypted request payloads?**
Centralised `EncryptionUtil` class using AES/CBC/PKCS5Padding. The Service layer handles the encryption flow: build plain payload → serialise to JSON → encrypt → wrap in `EncryptedRequestWrapper` → send. Tests never deal with encryption directly.

**Q: How do you manage API tokens across tests?**
Thread-safe `TokenManager` singleton with lazy initialisation and caching. Tokens are cached until expiry (checked via JWT decode or configured TTL). Separate caches for ACCESS and TRANSACTION tokens. Transaction tokens are cached per orderHash.

**Q: What is the Service Layer pattern?**
An abstraction between tests and HTTP calls. Services know how to build payloads, handle encryption, add auth headers, and call the right endpoints. Tests call service methods (`customerService.createRandomCustomer()`) and validate responses. This keeps tests focused on business assertions.

**Q: How do you generate test data?**
`DataGenerator` using JavaFaker with Indian locale. Generates realistic names, 10-digit mobile numbers (starting with 6-9), email addresses, addresses, amounts, and unique reference numbers. Negative data helpers generate empty strings, null values, special characters, and boundary values.

**Q: How do you handle logging without exposing secrets?**
Custom `RequestLoggingFilter` that regex-masks card numbers (show first 6 + last 4), CVVs (replace with ***), Bearer tokens (show first 10 chars + MASKED), and API keys. The filter runs on every request before logging. Production environments always have `log.sensitive.mask=true`.

---

## Common Mistakes & Anti-Patterns

### Mistake 1: Tests That Know HTTP Details
```java
// BAD — test knows about headers, content type, encryption
@Test
public void testCreateCustomer() {
    given()
        .header("Authorization", "Bearer " + getToken())
        .contentType(ContentType.JSON)
        .body(encrypt(payload, key))
        .post("/transaction/v1/customer/create");
}

// GOOD — test knows only business intent
@Test
public void testCreateCustomer() {
    Response response = customerService.createRandomCustomer(encKey);
    validate(response).validateSuccess().assertAll();
}
```

### Mistake 2: Hardcoded Test Data
```java
// BAD — fails on second run (duplicate), fails in other environments
.body("{\"merchantCustomerId\":\"CUST001\"}")

// GOOD — unique every run
.body(CustomerCreateRequest.builder()
    .merchantCustomerId(DataGenerator.merchantCustomerId())  // unique
    .build())
```

### Mistake 3: No Assertions Beyond Status Code
```java
// BAD — only checks HTTP status
response.then().statusCode(200);

// GOOD — validates business logic
validate(response)
    .validateSuccess()
    .validateFieldNotNull("data[0].customerId")
    .validateFieldEquals("data[0].status", "ACTIVE")
    .validateResponseTime(3000)
    .assertAll();
```

### Mistake 4: Ignoring Error Scenarios
Only testing happy paths misses 60% of bugs. Always test: missing required fields, invalid formats, boundary values, wrong auth, duplicate data, expired tokens, wrong HTTP methods.

### Mistake 5: Not Using Soft Assertions
Hard assertions hide failures. If a test checks 10 fields and the 2nd fails, you never learn about the other 8. Use soft assertions (our `ResponseValidator` does this by default).

### Mistake 6: Sleeping Instead of Polling
```java
// BAD — arbitrary sleep
Thread.sleep(5000);

// GOOD — poll until condition or timeout
Awaitility.await()
    .atMost(30, SECONDS)
    .pollInterval(2, SECONDS)
    .until(() -> getOrderStatus(orderId).equals("COMPLETED"));
```

### Mistake 7: Not Cleaning Test Data
Tests that create data should ideally clean up after themselves (delete customer, cancel order). Prevents test data accumulation and environment degradation. Use `@AfterMethod` or `@AfterClass` for cleanup.

---

## Quick Reference Card

### Run Commands
```bash
# Local execution
mvn test -Psit -Psmoke           # Smoke on SIT
mvn test -Puat -Pregression      # Regression on UAT
mvn test -Psit -Pe2e             # E2E on SIT

# With specific test class
mvn test -Dtest=CustomerTest     # Run one test class

# Docker
docker build -t sbiepay-tests .
docker run --rm -e ENV=sit -e SUITE=smoke sbiepay-tests

# View reports
open target/reports/extent-report.html
```

### File Locations
```
Config:    src/main/resources/config/config.properties
Env:       src/main/resources/environments/{sit|uat|prod}.properties
Logs:      target/logs/automation.log
Reports:   target/reports/extent-report.html
Templates: src/main/resources/testdata/json/requests/*.json
Schemas:   src/main/resources/testdata/json/schemas/*.json
Suites:    src/test/resources/suites/testng-{smoke|regression|e2e}.xml
```

---

*Generated for the SBIePay API Automation Framework.*
*Framework version: 1.0.0 | REST Assured 5.4.0 | TestNG 7.9.0 | Java 17*
